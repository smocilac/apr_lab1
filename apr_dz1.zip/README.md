# apr_lab1

Lab1 APR - Matrice; LU dekompozicija


# Build and run:

mkdir build
cd build
cmake ..
make
./lab1
